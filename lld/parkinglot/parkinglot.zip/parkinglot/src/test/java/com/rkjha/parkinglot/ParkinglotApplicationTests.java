package com.rkjha.parkinglot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParkinglotApplicationTests {

	@Test
	void contextLoads() {
	}

}
